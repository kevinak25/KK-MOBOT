#include "ota.h"
#include "esp_log.h"
#include "esp_https_ota.h"
#include "esp_system.h"

static const char *TAG = "OTA";

void start_ota_update(const char *url) {
    esp_http_client_config_t config = {
        .url = url,
        // .cert_pem = NULL // Solo si necesitas un certificado TLS (puede omitirse si el servidor permite conexiones sin validación de certificado)
    };

    esp_err_t ret = esp_https_ota(&config);
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "✅ OTA completada, reiniciando...");
        esp_restart();
    } else {
        ESP_LOGE(TAG, "❌ OTA fallida: %s", esp_err_to_name(ret));
    }
}
