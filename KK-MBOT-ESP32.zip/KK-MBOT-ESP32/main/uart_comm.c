#include "uart_comm.h"
#include "driver/uart.h"
#include <string.h>

#define UART_NUM UART_NUM_1
#define BUF_SIZE 1024
#define UART_TX_PIN 32
#define UART_RX_PIN 33

void uart_comm_init(void) {
    uart_config_t config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
    };
    uart_driver_install(UART_NUM, BUF_SIZE * 2, 0, 0, NULL, 0);
    uart_param_config(UART_NUM, &config);
    uart_set_pin(UART_NUM, UART_TX_PIN, UART_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
}

void uart_comm_send(const char *data) {
    uart_write_bytes(UART_NUM, data, strlen(data));
    uart_write_bytes(UART_NUM, "\n", 1);  // salto de linea para indicar que el mensaje se ha acabado
}

int uart_comm_receive(char *buf, int max_len) {
    int len = uart_read_bytes(UART_NUM, (uint8_t *)buf, max_len - 1, pdMS_TO_TICKS(100));
    if (len > 0) {
        buf[len] = '\0';
        return len;
    }
    return 0;
}
