#pragma once

void mqtt_bridge_start(void);
void mqtt_uart_publish(const char *msg);
