#pragma once

#include "driver/uart.h"

// Inicializa la UART en GPIO 32 (RX) y GPIO 33 (TX)
void uart_comm_init(void);

// Envía una cadena por UART
void uart_comm_send(const char *data);

// Lee una línea (hasta '\n') de UART. Retorna longitud o 0 si no hay datos.
int uart_comm_receive(char *buf, int max_len);
