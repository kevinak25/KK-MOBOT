#ifndef OTA_H
#define OTA_H

void start_ota_update(const char *url);

#endif
