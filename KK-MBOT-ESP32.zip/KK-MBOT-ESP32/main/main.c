
/*
 * Comandos válidos por MQTT → UART:
 * - MOVER:<accion>:<duracion_ms>         Ej: MOVER:AVANZAR:1000
 * - BRAZO:<m1>:<m2>:<m3>:<gripper>       Ej: BRAZO:90:120:45:1
 *
 * Acciones válidas para MOVER: AVANZAR, RETROCEDER, IZQUIERDA, DERECHA,
 * DIAG_IZQ_FWD, DIAG_DER_FWD, DIAG_IZQ_BACK, DIAG_DER_BACK, DETENER
 */

 #include <string.h>            // Para strncmp()
#include "esp_log.h"           // Para ESP_LOGI, ESP_LOGW, etc.
#include "mqtt_bridge.h"       // Para mqtt_bridge_start(), mqtt_uart_publish()
#include "uart_comm.h"         // Para uart_comm_init(), uart_comm_send(), uart_comm_receive()

#include "esp_netif.h"
#include "esp_event.h"
#include "esp_wifi.h"
#include "esp_mac.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"


#define WIFI_SSID      "xxxxx"
#define WIFI_PASS      "xxxxx"

static const char *TAG = "MAIN";

bool comando_valido(const char *cmd) {
    return strncmp(cmd, "MOVER:", 6) == 0 || strncmp(cmd, "BRAZO:", 6) == 0;
}

void wifi_init_sta(void) {
    esp_netif_init();
    esp_event_loop_create_default();
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_wifi_init(&cfg);

    wifi_config_t wifi_config = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASS,
        },
    };

    esp_wifi_set_mode(WIFI_MODE_STA);
    esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    esp_wifi_start();
    esp_wifi_connect();
}

void app_main(void) {
    ESP_ERROR_CHECK(nvs_flash_init());
    wifi_init_sta();
    mqtt_bridge_start();
    uart_comm_init();

    while (1) {
        char buf[128];
        int len = uart_comm_receive(buf, sizeof(buf));
        if (len > 0) {
            ESP_LOGI(TAG, "📤 UART→MQTT: %s", buf);
            mqtt_uart_publish(buf);
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

// Esta función se llama desde mqtt_bridge.c si se quiere validar antes de enviar a UART
void mqtt_recibir_comando(const char *mensaje) {
    if (comando_valido(mensaje)) {
        ESP_LOGI(TAG, "✅ Comando válido, enviando a UART: %s", mensaje);
        uart_comm_send(mensaje);
    } else {
        ESP_LOGW(TAG, "❌ Comando no reconocido: %s", mensaje);
        mqtt_uart_publish("❌ Comando no reconocido\n");
    }
}
