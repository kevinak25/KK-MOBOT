#include "mqtt_bridge.h"
#include "esp_log.h"
#include "mqtt_client.h"
#include "uart_comm.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static const char *TAG = "MQTT";
static esp_mqtt_client_handle_t client = NULL;

// Redirigir logs a MQTT
static int custom_log_vprintf(const char *fmt, va_list args) {
    static char buf[256];
    int len = vprintf(fmt, args);  // UART
    vsnprintf(buf, sizeof(buf), fmt, args);
    if (client) {
        esp_mqtt_client_publish(client, "esp32/logs", buf, 0, 1, 0);
    }
    return len;
}

// Manejador de eventos MQTT
static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data) {
    esp_mqtt_event_handle_t event = event_data;

    switch ((esp_mqtt_event_id_t)event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "📡 MQTT conectado");
            esp_mqtt_client_subscribe(client, "esp32/uart/in", 0);
            break;

        case MQTT_EVENT_DATA: {
            char mensaje[128] = {0};
            snprintf(mensaje, sizeof(mensaje), "%.*s", event->data_len, event->data);
            ESP_LOGI(TAG, "📥 MQTT→UART: %s", mensaje);
            uart_comm_send(mensaje);
            break;
        }

        default:
            break;
    }
}

void mqtt_bridge_start(void) {
    esp_mqtt_client_config_t config = {
        .broker.address.uri = "mqtt://192.168.0.21"
    };

    client = esp_mqtt_client_init(&config);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_mqtt_client_start(client);
    esp_log_set_vprintf(&custom_log_vprintf);
}

void mqtt_uart_publish(const char *msg) {
    if (client) {
        esp_mqtt_client_publish(client, "esp32/uart/out", msg, 0, 1, 0);
    }
}
