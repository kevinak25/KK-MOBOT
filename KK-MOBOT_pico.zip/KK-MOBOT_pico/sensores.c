// sensores.c
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "hardware/gpio.h"
#include "sensores.h"
#include "max17260.h"
#include "bmi2.h"
#include "bmi270.h"

#define I2C_PORT i2c1
#define SDA_PIN 2
#define SCL_PIN 3
#define ALRT_PIN 6
#define BMI270_I2C_ADDR 0x68
#define RSENSE_MOHMS 10.0f

static struct bmi2_dev bmi270_dev;

// Funciones externas necesarias para BMI270
int8_t bmi2_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr);
int8_t bmi2_i2c_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr);
void bmi2_delay_us(uint32_t period, void *intf_ptr);

void sensores_init(void) {
    printf("🔧 Inicializando I2C...\n");
    i2c_init(I2C_PORT, 400 * 1000);
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(SDA_PIN);
    gpio_pull_up(SCL_PIN);

    printf("🔋 Inicializando MAX17260...\n");
    max17260_init(I2C_PORT);

    gpio_init(ALRT_PIN);
    gpio_set_dir(ALRT_PIN, GPIO_IN);
    gpio_pull_up(ALRT_PIN);

    printf("📦 Inicializando BMI270...\n");

    // Configuración de interfaz para BMI270
    bmi270_dev.intf = BMI2_I2C_INTF;
    bmi270_dev.read = bmi2_i2c_read;
    bmi270_dev.write = bmi2_i2c_write;
    bmi270_dev.delay_us = bmi2_delay_us;
    bmi270_dev.read_write_len = 32;
    static uint8_t bmi_addr = BMI270_I2C_ADDR;
    bmi270_dev.intf_ptr = &bmi_addr;

    if (bmi270_init(&bmi270_dev) != BMI2_OK) {
        printf("❌ Error al inicializar el BMI270\n");
        return;
    }

    uint8_t sens_list[2] = { BMI2_ACCEL, BMI2_GYRO };
    if (bmi270_sensor_enable(sens_list, 2, &bmi270_dev) != BMI2_OK) {
        printf("❌ Error al habilitar sensores del BMI270\n");
        return;
    }

    printf("✅ Sensores inicializados correctamente\n");
}

bool leer_sensores(datos_sensores_t *datos) {
    if (!datos) return false;

    // Lecturas del MAX17260
    datos->voltaje = max17260_read_voltage(I2C_PORT);
    datos->soc = max17260_read_soc(I2C_PORT);
    datos->corriente = max17260_read_current(I2C_PORT, RSENSE_MOHMS);
    datos->temperatura = max17260_read_temperature(I2C_PORT);
    datos->alerta_activa = (gpio_get(ALRT_PIN) == 0);

    // Lectura de acelerómetro y giroscopio del BMI270
    struct bmi2_sens_data sensor_data = {0};
    if (bmi2_get_sensor_data(&sensor_data, &bmi270_dev) == BMI2_OK) {
        datos->acc_x = sensor_data.acc.x;
        datos->acc_y = sensor_data.acc.y;
        datos->acc_z = sensor_data.acc.z;
        datos->gyr_x = sensor_data.gyr.x;
        datos->gyr_y = sensor_data.gyr.y;
        datos->gyr_z = sensor_data.gyr.z;
        return true;
    } else {
        printf("❌ Error al leer datos del BMI270\n");
        return false;
    }
}
