#include "bmi270_port.h"
#include "pico/stdlib.h"
#include "hardware/i2c.h"

#define I2C_PORT i2c1

int8_t bmi2_i2c_read(uint8_t reg_addr, uint8_t *data, uint32_t len, void *intf_ptr) {
    uint8_t dev_addr = *(uint8_t *)intf_ptr;
    i2c_write_blocking(I2C_PORT, dev_addr, &reg_addr, 1, true);
    i2c_read_blocking(I2C_PORT, dev_addr, data, len, false);
    return 0;
}

int8_t bmi2_i2c_write(uint8_t reg_addr, const uint8_t *data, uint32_t len, void *intf_ptr) {
    uint8_t dev_addr = *(uint8_t *)intf_ptr;
    uint8_t buf[len + 1];
    buf[0] = reg_addr;
    for (uint32_t i = 0; i < len; i++) {
        buf[i + 1] = data[i];
    }
    i2c_write_blocking(I2C_PORT, dev_addr, buf, len + 1, false);
    return 0;
}

void bmi2_delay_us(uint32_t period, void *intf_ptr) {
    sleep_us(period);
}
