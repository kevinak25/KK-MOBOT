#include "max17260.h"
#include <stdio.h>

void max17260_init(i2c_inst_t *i2c) {
    // No requiere configuración inicial para lecturas básicas
}

static bool max17260_read_register(i2c_inst_t *i2c, uint8_t reg, uint16_t *value) {
    int ret = i2c_write_blocking(i2c, MAX17260_ADDR, &reg, 1, true);
    if (ret < 0) return false;

    uint8_t buf[2] = {0};
    ret = i2c_read_blocking(i2c, MAX17260_ADDR, buf, 2, false);
    if (ret < 0) return false;

    *value = ((uint16_t)buf[1] << 8) | buf[0]; // Little endian
    return true;
}

float max17260_read_voltage(i2c_inst_t *i2c) {
    uint16_t raw;
    if (!max17260_read_register(i2c, MAX17260_REG_VCELL, &raw)) {
        printf("❌ Error leyendo VCELL\n");
        return -1.0f;
    }
    return raw * 0.000078125f; // 78.125 uV por LSB
}

float max17260_read_soc(i2c_inst_t *i2c) {
    uint16_t raw;
    if (!max17260_read_register(i2c, MAX17260_REG_SOC, &raw)) {
        printf("❌ Error leyendo SOC\n");
        return -1.0f;
    }
    return (float)(raw & 0xFF); // Parte entera del SOC
}

float max17260_read_current(i2c_inst_t *i2c, float rsense_mohms) {
    uint16_t raw;
    if (!max17260_read_register(i2c, MAX17260_REG_CURRENT, &raw)) {
        printf("❌ Error leyendo CURRENT\n");
        return -999.0f;
    }

    int16_t current_raw = (int16_t)raw;
    float voltage_uV = current_raw * 1.5625f; // LSB: 1.5625 µV
    return voltage_uV / rsense_mohms; // mA = uV / mΩ
}

float max17260_read_temperature(i2c_inst_t *i2c) {
    uint16_t raw;
    if (!max17260_read_register(i2c, MAX17260_REG_TEMP, &raw)) {
        printf("❌ Error leyendo TEMPERATURA\n");
        return -999.0f;
    }
    return raw * (1.0f / 256.0f); // LSB: 1/256 ºC
}

uint16_t max17260_read_status(i2c_inst_t *i2c) {
    uint16_t raw;
    if (!max17260_read_register(i2c, MAX17260_REG_STATUS, &raw)) {
        printf("❌ Error leyendo STATUS\n");
        return 0xFFFF;
    }
    return raw;
}
