#include "pico/stdlib.h"
#include "hardware/uart.h"
#include <string.h>
#include <stdio.h>

#define UART_ID uart0
#define BAUD_RATE 115200
#define UART_TX_PIN 0
#define UART_RX_PIN 1

static volatile bool uart_en_uso = false;

void uart_comm_init(void) {
    uart_init(UART_ID, BAUD_RATE);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
}

// Enviar texto por UART con \r\n y semáforo
void uart_comm_send(const char *data) {
    while (uart_en_uso);
    uart_en_uso = true;

    uart_puts(UART_ID, data);
    uart_puts(UART_ID, "\r\n");  // <- necesario para que ESP32 detecte el fin de línea

    uart_en_uso = false;
}

int uart_comm_receive(char *buffer, size_t max_len) {
    size_t i = 0;
    while (i < max_len - 1) {
        if (uart_is_readable(UART_ID)) {
            char c = uart_getc(UART_ID);
            if (c == '\n' || c == '\r') break;
            buffer[i++] = c;
        }
    }
    buffer[i] = '\0';
    return i;
}
