#ifndef MOTORES_H
#define MOTORES_H

#include <stdint.h>
#include <stdbool.h>

void mover_motor_individual(uint8_t motor_id, bool adelante, uint8_t velocidad);
void configurar_todos_los_motores(void);
void avanzar(uint8_t vel);
void retroceder(uint8_t vel);
void girar_derecha(uint8_t vel);
void girar_izquierda(uint8_t vel);
void mover_diagonal_izquierda_adelante(uint8_t vel);
void mover_diagonal_derecha_adelante(uint8_t vel);
void mover_diagonal_izquierda_atras(uint8_t vel);
void mover_diagonal_derecha_atras(uint8_t vel);
void detener(void);

#endif