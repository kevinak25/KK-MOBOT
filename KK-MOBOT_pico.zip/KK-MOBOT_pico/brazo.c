#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "uart_comm.h"
#include <stdio.h>
#include <stdbool.h>

#define PCA9685_ADDR 0x41
#define I2C_PORT i2c1
#define I2C_SDA 2
#define I2C_SCL 3

#define PCA9685_MODE1     0x00
#define PCA9685_PRESCALE  0xFE
#define PCA9685_LED0_ON_L 0x06

static bool pca9685_conectado = false;

bool brazo_is_conectado() {
    return pca9685_conectado;
}

void brazo_init() {
    i2c_init(I2C_PORT, 400 * 1000);
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);

    uint8_t mode1;
    int res = i2c_write_blocking(I2C_PORT, PCA9685_ADDR, (uint8_t[]){PCA9685_MODE1}, 1, true);
    if (res < 0 || i2c_read_blocking(I2C_PORT, PCA9685_ADDR, &mode1, 1, false) < 0) {
        uart_comm_send("PCA9685 no detectado");
        pca9685_conectado = false;
        return;
    }

    pca9685_conectado = true;
    uart_comm_send("PCA9685 detectado correctamente");

    uint8_t data[2];

    // Sleep
    data[0] = PCA9685_MODE1; data[1] = 0x10;
    if (i2c_write_blocking(I2C_PORT, PCA9685_ADDR, data, 2, false) < 0) {
        uart_comm_send("Error al poner en modo sleep");
        pca9685_conectado = false;
        return;
    }

    // Prescaler (para ~50 Hz)
    data[0] = PCA9685_PRESCALE; data[1] = 121;
    if (i2c_write_blocking(I2C_PORT, PCA9685_ADDR, data, 2, false) < 0) {
        uart_comm_send("Error al configurar prescaler");
        pca9685_conectado = false;
        return;
    }

    // Wake up
    data[0] = PCA9685_MODE1; data[1] = 0x00;
    if (i2c_write_blocking(I2C_PORT, PCA9685_ADDR, data, 2, false) < 0) {
        uart_comm_send("Error al salir de modo sleep");
        pca9685_conectado = false;
        return;
    }

    sleep_ms(10);

    // Auto-incremento
    data[0] = PCA9685_MODE1; data[1] = 0xA1;
    if (i2c_write_blocking(I2C_PORT, PCA9685_ADDR, data, 2, false) < 0) {
        uart_comm_send("Error al activar auto-incremento");
        pca9685_conectado = false;
        return;
    }

    uart_comm_send("PCA9685 inicializado con éxito");
}

uint16_t angle_to_pwm(uint8_t angle) {
    if (angle > 180) angle = 180;
    if (angle < 0) angle = 0;
    return 204 + (angle * (409 - 204)) / 180;
}

void set_pwm(uint8_t channel, uint16_t on, uint16_t off) {
    uint8_t reg = PCA9685_LED0_ON_L + 4 * channel;
    uint8_t data[5] = {
        reg,
        on & 0xFF,
        (on >> 8) & 0xFF,
        off & 0xFF,
        (off >> 8) & 0xFF
    };

    if (i2c_write_blocking(I2C_PORT, PCA9685_ADDR, data, 5, false) < 0) {
        char msg[64];
        snprintf(msg, sizeof(msg), "Fallo en set_pwm para canal %d", channel);
        uart_comm_send(msg);
        pca9685_conectado = false;
    } else {
        char ok[48];
        snprintf(ok, sizeof(ok), "Canal %d actualizado correctamente", channel);
        uart_comm_send(ok);
    }
}

void brazo_mover(uint8_t ang1, uint8_t ang2, uint8_t ang3, bool gripper_on) {
    if (!pca9685_conectado) {
        uart_comm_send("No se puede mover el brazo: PCA9685 no conectado");
        return;
    }

    char msg[64];
    snprintf(msg, sizeof(msg), "Moviendo brazo: %d %d %d GRIP:%s", ang1, ang2, ang3, gripper_on ? "ON" : "OFF");
    uart_comm_send(msg);

    set_pwm(0, 0, angle_to_pwm(ang1));
    sleep_ms(5);
    set_pwm(1, 0, angle_to_pwm(ang2));
    sleep_ms(5);
    set_pwm(2, 0, angle_to_pwm(ang3));
    sleep_ms(5);
    set_pwm(3, 0, gripper_on ? angle_to_pwm(30) : angle_to_pwm(90));
    sleep_ms(5);

    uart_comm_send("Brazo movido correctamente");
}
