#include "motores.h"
#include "pico/stdlib.h"
#include "hardware/pwm.h"

#define M1_IN1 16
#define M1_IN2 17
#define M1_EN  13

#define M2_IN1 12
#define M2_IN2 11
#define M2_EN  10

#define M3_IN1 7
#define M3_IN2 20
#define M3_EN  19

#define M4_IN1 14
#define M4_IN2 15
#define M4_EN  18

void configurar_pin_pwm(uint gpio) {
    gpio_set_function(gpio, GPIO_FUNC_PWM);
    uint slice = pwm_gpio_to_slice_num(gpio);
    pwm_set_wrap(slice, 255);
    pwm_set_enabled(slice, true);
}

void configurar_motor(uint in1, uint in2, uint en) {
    gpio_init(in1); gpio_set_dir(in1, GPIO_OUT);
    gpio_init(in2); gpio_set_dir(in2, GPIO_OUT);
    configurar_pin_pwm(en);
}

void mover_motor(uint in1, uint in2, uint en, bool adelante, uint8_t velocidad) {
    gpio_put(in1, adelante);
    gpio_put(in2, !adelante);
    uint slice = pwm_gpio_to_slice_num(en);
    pwm_set_chan_level(slice, pwm_gpio_to_channel(en), velocidad);
}

void avanzar(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, true, velocidad);
    mover_motor(M2_IN1, M2_IN2, M2_EN, true, velocidad);
    mover_motor(M3_IN1, M3_IN2, M3_EN, true, velocidad);
    mover_motor(M4_IN1, M4_IN2, M4_EN, true, velocidad);
}

void retroceder(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, false, velocidad);
    mover_motor(M2_IN1, M2_IN2, M2_EN, false, velocidad);
    mover_motor(M3_IN1, M3_IN2, M3_EN, false, velocidad);
    mover_motor(M4_IN1, M4_IN2, M4_EN, false, velocidad);
}

void girar_izquierda(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, false, velocidad);
    mover_motor(M2_IN1, M2_IN2, M2_EN, true, velocidad);
    mover_motor(M3_IN1, M3_IN2, M3_EN, false, velocidad);
    mover_motor(M4_IN1, M4_IN2, M4_EN, true, velocidad);
}

void girar_derecha(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, true, velocidad);
    mover_motor(M2_IN1, M2_IN2, M2_EN, false, velocidad);
    mover_motor(M3_IN1, M3_IN2, M3_EN, true, velocidad);
    mover_motor(M4_IN1, M4_IN2, M4_EN, false, velocidad);
}

void mover_diagonal_izquierda_adelante(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, false, 0);
    mover_motor(M2_IN1, M2_IN2, M2_EN, true, velocidad);
    mover_motor(M3_IN1, M3_IN2, M3_EN, true, velocidad);
    mover_motor(M4_IN1, M4_IN2, M4_EN, false, 0);
}

void mover_diagonal_derecha_adelante(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, true, velocidad);
    mover_motor(M2_IN1, M2_IN2, M2_EN, false, 0);
    mover_motor(M3_IN1, M3_IN2, M3_EN, false, 0);
    mover_motor(M4_IN1, M4_IN2, M4_EN, true, velocidad);
}

void mover_diagonal_izquierda_atras(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, false, velocidad);
    mover_motor(M2_IN1, M2_IN2, M2_EN, true, 0);
    mover_motor(M3_IN1, M3_IN2, M3_EN, true, 0);
    mover_motor(M4_IN1, M4_IN2, M4_EN, false, velocidad);
}

void mover_diagonal_derecha_atras(uint8_t velocidad) {
    mover_motor(M1_IN1, M1_IN2, M1_EN, true, 0);
    mover_motor(M2_IN1, M2_IN2, M2_EN, false, velocidad);
    mover_motor(M3_IN1, M3_IN2, M3_EN, false, velocidad);
    mover_motor(M4_IN1, M4_IN2, M4_EN, true, 0);
}

void detener() {
    mover_motor(M1_IN1, M1_IN2, M1_EN, true, 0);
    mover_motor(M2_IN1, M2_IN2, M2_EN, true, 0);
    mover_motor(M3_IN1, M3_IN2, M3_EN, true, 0);
    mover_motor(M4_IN1, M4_IN2, M4_EN, true, 0);
}

void configurar_todos_los_motores() {
    configurar_motor(M1_IN1, M1_IN2, M1_EN);
    configurar_motor(M2_IN1, M2_IN2, M2_EN);
    configurar_motor(M3_IN1, M3_IN2, M3_EN);
    configurar_motor(M4_IN1, M4_IN2, M4_EN);
}
void mover_motor_individual(uint8_t motor_id, bool adelante, uint8_t velocidad) {
    switch (motor_id) {
        case 1:
            mover_motor(M1_IN1, M1_IN2, M1_EN, adelante, velocidad);
            break;
        case 2:
            mover_motor(M2_IN1, M2_IN2, M2_EN, adelante, velocidad);
            break;
        case 3:
            mover_motor(M3_IN1, M3_IN2, M3_EN, adelante, velocidad);
            break;
        case 4:
            mover_motor(M4_IN1, M4_IN2, M4_EN, adelante, velocidad);
            break;
    }
}
