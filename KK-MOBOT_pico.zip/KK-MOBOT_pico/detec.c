#include "detec.h"
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "motores.h"
#include "uart_comm.h"

#define TRIG_PIN 4
#define ECHO_PIN 5
#define DISTANCIA_UMBRAL_CM 20.0

void detec_init(void) {
    gpio_init(TRIG_PIN);
    gpio_set_dir(TRIG_PIN, GPIO_OUT);
    gpio_put(TRIG_PIN, 0);

    gpio_init(ECHO_PIN);
    gpio_set_dir(ECHO_PIN, GPIO_IN);
}

float medir_distancia_cm(void) {
    // Disparo de 10us
    gpio_put(TRIG_PIN, 1);
    sleep_us(10);
    gpio_put(TRIG_PIN, 0);

    // Espera a que el pin ECHO suba
    absolute_time_t start = get_absolute_time();
    while (!gpio_get(ECHO_PIN)) {
        if (absolute_time_diff_us(start, get_absolute_time()) > 1000000) return -1;
    }

    // Medir duración del pulso
    absolute_time_t echo_start = get_absolute_time();
    while (gpio_get(ECHO_PIN)) {
        if (absolute_time_diff_us(echo_start, get_absolute_time()) > 30000) return -1;
    }
    absolute_time_t echo_end = get_absolute_time();

    int64_t pulse_us = absolute_time_diff_us(echo_start, echo_end);
    float distancia_cm = pulse_us / 58.0f;  // Conversión típica

    return distancia_cm;
}

void evadir_obstaculo(void) {
    uart_comm_send("🚧 Objeto detectado. Evadiendo...\n");
    detener();
    sleep_ms(300);
    girar_derecha(150);
    sleep_ms(600);
    avanzar(150);
    sleep_ms(600);
    girar_izquierda(150);
    sleep_ms(600);
    detener();
    uart_comm_send("✅ Evasión completada\n");
}
