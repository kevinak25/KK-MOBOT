// sensores.h
#ifndef SENSORES_H
#define SENSORES_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
    float voltaje;
    float soc;
    float corriente;
    float temperatura;
    bool alerta_activa;
    int16_t acc_x, acc_y, acc_z;
    int16_t gyr_x, gyr_y, gyr_z;
} datos_sensores_t;

void sensores_init(void);
bool leer_sensores(datos_sensores_t *datos);

#endif
