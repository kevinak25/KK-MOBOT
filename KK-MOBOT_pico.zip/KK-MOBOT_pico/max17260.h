#ifndef MAX17260_H
#define MAX17260_H

#include "hardware/i2c.h"

// Dirección I2C del MAX17260
#define MAX17260_ADDR 0x36

// Registros del MAX17260
#define MAX17260_REG_VCELL    0x09
#define MAX17260_REG_SOC      0x06
#define MAX17260_REG_CURRENT  0x0A
#define MAX17260_REG_TEMP     0x08
#define MAX17260_REG_STATUS   0x00

void max17260_init(i2c_inst_t *i2c);
float max17260_read_voltage(i2c_inst_t *i2c);
float max17260_read_soc(i2c_inst_t *i2c);
float max17260_read_current(i2c_inst_t *i2c, float rsense_mohms);
float max17260_read_temperature(i2c_inst_t *i2c);
uint16_t max17260_read_status(i2c_inst_t *i2c);

#endif
