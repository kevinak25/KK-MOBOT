// main.c - Control principal del robot móvil autónomo
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/timer.h"
#include "hardware/gpio.h"
#include "sensores.h"
#include "uart_comm.h"
#include "motores.h"
#include "brazo.h"
#include "detec.h"

#define COMANDO_MAX_LEN 64
#define PERIODO_ULTRASONICO_MS 300
#define DISTANCIA_UMBRAL_CM 20.0
#define LED_PIN 25
#define ENVIO_OBSTACULO_DELAY_MS 60000

int velocidad_actual = 180;
int tiempo_defecto = 1000;
bool evasion_activada = false;
absolute_time_t proxima_medicion;
absolute_time_t proximo_envio_obstaculo;

void ejecutar_comando(const char* comando) {
    char cmd[COMANDO_MAX_LEN];
    strncpy(cmd, comando, COMANDO_MAX_LEN);
    cmd[strcspn(cmd, "\r\n")] = 0;

    char* accion = strtok(cmd, " ");
    if (!accion) {
        uart_comm_send("ERROR: Comando vacio");
        return;
    }

    if (strcmp(accion, "SET_VEL") == 0) {
        char* val = strtok(NULL, " ");
        if (val) {
            velocidad_actual = atoi(val);
            char msg[64];
            snprintf(msg, sizeof(msg), "Velocidad actual: %d", velocidad_actual);
            uart_comm_send(msg);
        } else {
            uart_comm_send("ERROR: Falta valor para SET_VEL");
        }
        return;
    }

    if (strcmp(accion, "SET_T_MS") == 0) {
        char* val = strtok(NULL, " ");
        if (val) {
            tiempo_defecto = atoi(val);
            char msg[64];
            snprintf(msg, sizeof(msg), "Tiempo por defecto: %d ms", tiempo_defecto);
            uart_comm_send(msg);
        } else {
            uart_comm_send("ERROR: Falta valor para SET_T_MS");
        }
        return;
    }

    if (strcmp(accion, "GET_CONFIG") == 0) {
        char msg[128];
        snprintf(msg, sizeof(msg), "Velocidad=%d | Tiempo=%d ms", velocidad_actual, tiempo_defecto);
        uart_comm_send(msg);
        return;
    }

    if (strcmp(accion, "EVADE_ON") == 0) {
        evasion_activada = true;
        uart_comm_send("Evasion activada");
        return;
    }

    if (strcmp(accion, "EVADE_OFF") == 0) {
        evasion_activada = false;
        uart_comm_send("Evasion desactivada");
        return;
    }

    if (strcmp(accion, "SENSORES") == 0) {
        datos_sensores_t datos;
        if (leer_sensores(&datos)) {
            char buf[256];
            snprintf(buf, sizeof(buf),
                "V=%.3fV SOC=%.1f%% I=%.1fmA T=%.1fC ALRT=%s\n"
                "Accel: X=%d Y=%d Z=%d | Gyro: X=%d Y=%d Z=%d",
                datos.voltaje, datos.soc, datos.corriente, datos.temperatura,
                datos.alerta_activa ? "LOW" : "HIGH",
                datos.acc_x, datos.acc_y, datos.acc_z,
                datos.gyr_x, datos.gyr_y, datos.gyr_z);
            uart_comm_send(buf);
        } else {
            uart_comm_send("ERROR: No se pudo leer sensores");
        }
        return;
    }

    if (strcmp(accion, "DISTANCIA") == 0) {
        float distancia = medir_distancia_cm();
        if (distancia > 0) {
            char msg[64];
            snprintf(msg, sizeof(msg), "Distancia medida: %.2f cm", distancia);
            uart_comm_send(msg);
        } else {
            uart_comm_send("ERROR: No se pudo medir distancia");
        }
        return;
    }

    if (strcmp(accion, "MOTOR") == 0) {
        char* id_str = strtok(NULL, " ");
        char* dir = strtok(NULL, " ");
        char* vel_str = strtok(NULL, " ");
        if (id_str && dir && vel_str) {
            uint8_t id = atoi(id_str);
            uint8_t vel = atoi(vel_str);
            bool adelante = strcmp(dir, "FWD") == 0;
            mover_motor_individual(id, adelante, vel);
            char msg[64];
            snprintf(msg, sizeof(msg), "Motor %d %s a velocidad %d", id, adelante ? "adelante" : "atras", vel);
            uart_comm_send(msg);
        } else {
            uart_comm_send("ERROR: Uso correcto: MOTOR <id> <FWD|REV> <vel>");
        }
        return;
    }

    if (strcmp(accion, "BRAZO") == 0) {
        char* a1 = strtok(NULL, " ");
        char* a2 = strtok(NULL, " ");
        char* a3 = strtok(NULL, " ");
        char* grip = strtok(NULL, " ");
        if (a1 && a2 && a3 && grip) {
            uint8_t ang1 = atoi(a1);
            uint8_t ang2 = atoi(a2);
            uint8_t ang3 = atoi(a3);
            bool gripper_on = strcmp(grip, "ON") == 0;
            brazo_mover(ang1, ang2, ang3, gripper_on);
            uart_comm_send("Brazo movido correctamente");
        } else {
            uart_comm_send("ERROR: Uso correcto: BRAZO A1 A2 A3 ON|OFF");
        }
        return;
    }

    if (strcmp(accion, "STATUS") == 0) {
        char estado[256];
        snprintf(estado, sizeof(estado),
            "Evasion: %s\nVelocidad: %d\nTiempo por defecto: %d ms\nBrazo: %s",
            evasion_activada ? "ACTIVADA" : "DESACTIVADA",
            velocidad_actual,
            tiempo_defecto,
            brazo_is_conectado() ? "CONECTADO" : "NO DETECTADO");
        uart_comm_send(estado);
        return;
    }

    if (strcmp(accion, "?") == 0) {
        uart_comm_send(
            "Comandos disponibles:\n"
            "SET_VEL <valor>\n"
            "SET_T_MS <milisegundos>\n"
            "GET_CONFIG\n"
            "EVADE_ON / EVADE_OFF\n"
            "SENSORES\n"
            "DISTANCIA\n"
            "STATUS\n"
            "MOTOR <id> <FWD|REV> <vel>\n"
            "BRAZO <A1> <A2> <A3> <ON|OFF>\n"
            "AVANZAR <t_ms>\n"
            "RETROCEDER <t_ms>\n"
            "IZQUIERDA <t_ms>\n"
            "DERECHA <t_ms>\n"
            "DIAG_IZQ_ADELANTE <t_ms>\n"
            "DIAG_DER_ADELANTE <t_ms>\n"
            "DIAG_IZQ_ATRAS <t_ms>\n"
            "DIAG_DER_ATRAS <t_ms>\n"
            "DETENER");
        return;
    }

    char* tiempo_str = strtok(NULL, " ");
    int duracion_ms = tiempo_str ? atoi(tiempo_str) : tiempo_defecto;

    if (strcmp(accion, "AVANZAR") == 0) avanzar(velocidad_actual);
    else if (strcmp(accion, "RETROCEDER") == 0) retroceder(velocidad_actual);
    else if (strcmp(accion, "IZQUIERDA") == 0) girar_izquierda(velocidad_actual);
    else if (strcmp(accion, "DERECHA") == 0) girar_derecha(velocidad_actual);
    else if (strcmp(accion, "DIAG_IZQ_ADELANTE") == 0) mover_diagonal_izquierda_adelante(velocidad_actual);
    else if (strcmp(accion, "DIAG_DER_ADELANTE") == 0) mover_diagonal_derecha_adelante(velocidad_actual);
    else if (strcmp(accion, "DIAG_IZQ_ATRAS") == 0) mover_diagonal_izquierda_atras(velocidad_actual);
    else if (strcmp(accion, "DIAG_DER_ATRAS") == 0) mover_diagonal_derecha_atras(velocidad_actual);
    else if (strcmp(accion, "DETENER") == 0) {
        detener();
        uart_comm_send("Detenido");
        return;
    } else {
        uart_comm_send("ERROR: Comando no reconocido");
        return;
    }

    char confirm[64];
    snprintf(confirm, sizeof(confirm), "Ejecutando %s por %d ms", accion, duracion_ms);
    uart_comm_send(confirm);
    sleep_ms(duracion_ms);
    detener();
    uart_comm_send("Movimiento completado");
}

int main() {
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    gpio_put(LED_PIN, 1);
    sleep_ms(3000);
    gpio_put(LED_PIN, 0);

    uart_comm_init();
    uart_comm_send("UART inicializada");

    sensores_init();
    uart_comm_send("sensores_init completado");

    brazo_init();
    uart_comm_send("brazo_init completado");

    configurar_todos_los_motores();
    uart_comm_send("motores configurados");

    detec_init();
    uart_comm_send("deteccion de obstaculos inicializada");

    proxima_medicion = make_timeout_time_ms(PERIODO_ULTRASONICO_MS);
    proximo_envio_obstaculo = make_timeout_time_ms(0);

    char comando[COMANDO_MAX_LEN];
    datos_sensores_t datos;

    while (true) {
        if (evasion_activada && absolute_time_diff_us(get_absolute_time(), proxima_medicion) < 0) {
            float distancia = medir_distancia_cm();
            if (distancia > 0 && distancia < DISTANCIA_UMBRAL_CM) {
                if (absolute_time_diff_us(get_absolute_time(), proximo_envio_obstaculo) < 0) {
                    if (leer_sensores(&datos)) {
                        char buf[256];
                        snprintf(buf, sizeof(buf),
                            "Objeto a %.2f cm\nAccel: X=%d Y=%d Z=%d | Gyro: X=%d Y=%d Z=%d",
                            distancia,
                            datos.acc_x, datos.acc_y, datos.acc_z,
                            datos.gyr_x, datos.gyr_y, datos.gyr_z);
                        uart_comm_send(buf);
                    } else {
                        uart_comm_send("ERROR: No se pudo leer sensores al detectar obstaculo");
                    }
                    evadir_obstaculo();
                    proximo_envio_obstaculo = make_timeout_time_ms(ENVIO_OBSTACULO_DELAY_MS);
                }
            }
            proxima_medicion = make_timeout_time_ms(PERIODO_ULTRASONICO_MS);
        }

        if (uart_is_readable(uart0)) {
            int n = uart_comm_receive(comando, sizeof(comando));
            if (n > 0) {
                comando[strcspn(comando, "\r\n")] = 0;
                ejecutar_comando(comando);
            }
        }

        sleep_ms(10);
    }

    return 0;
}
