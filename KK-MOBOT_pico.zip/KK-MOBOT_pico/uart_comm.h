#pragma once

#include <stddef.h>

// Inicializa la UART con los pines definidos
void uart_comm_init(void);

// Envía una cadena por UART
void uart_comm_send(const char *data);

// Recibe una línea (hasta '\n') y la guarda en el buffer
// Devuelve la cantidad de bytes leídos (sin incluir '\0')
int uart_comm_receive(char *buffer, size_t max_len);
