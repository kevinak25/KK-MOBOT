#ifndef DETEC_H
#define DETEC_H

void detec_init(void);
float medir_distancia_cm(void);
void evadir_obstaculo(void); // Implementación simple de evasión

#endif
