#ifndef BRAZO_H
#define BRAZO_H

#include <stdint.h>
#include <stdbool.h>

void brazo_init(void);
void brazo_mover(uint8_t ang1, uint8_t ang2, uint8_t ang3, bool gripper_on);
bool brazo_is_conectado(void);

#endif